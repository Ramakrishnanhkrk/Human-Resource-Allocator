﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HRA_MVC.Models
{
    public class EmployeeLogin
    {
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", ErrorMessage = "Invalid email address")]
        //[Required(ErrorMessage = "EmailId is mandatory.")]
        [DisplayName("Email Id :")]
        public string EmailId { get; set; }
        [StringLength(maximumLength: 10)]
        //[Required(ErrorMessage = "Password is mandatory")]
        [DisplayName("Password :")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        //[Required(ErrorMessage = "Confirm Password is mandatory")]
        [DisplayName("Confirm Password :")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Password and Confirm Password do not match")]
        public string ConfirmPassword { get; set; }
    }
}
