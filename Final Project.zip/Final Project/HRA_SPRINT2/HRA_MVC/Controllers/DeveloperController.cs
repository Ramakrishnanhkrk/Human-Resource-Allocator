﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using HRA_DAL;
using HRA_DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
namespace HRA_MVC.Controllers
{
    public class DeveloperController : Controller
    {
        private readonly HRA_DBContext _context;
        HRA_Repository repObj;
        private readonly IMapper _mapper;
        public DeveloperController(HRA_DBContext context, IMapper mapper)
        {
            _context = context;
            repObj = new HRA_Repository(_context);
            _mapper = mapper;
        }

                //-------------------Developer Login--------------------------------------
        public IActionResult DLogin()
        {
            return View();
        }

                //-------------------To verify the developer---------------------------------------
        public IActionResult CheckedLoginDetails(IFormCollection frm)
        {
            string userId = frm["name"];
            string password = frm["pwd"];
            TempData["EmailId"] = userId;
            bool res = repObj.emplogindetails(userId, password);
            if (res == true)
            {
                return RedirectToAction("Profile");
            }
            else
            {
                return RedirectToAction("ErrorPage","Alert");
                

            }
        }

                //------------------------------Developer SignUp----------------------------------
        public IActionResult DSignup()
        {
            return View();
        }

                //-------------------------------To save the new Developer---------------------------------
        public IActionResult SaveNewDeveloper(Models.EmployeeLogin userObj)
        {
            if (ModelState.IsValid)
            {
                var returnValue = repObj.AddEmployeeLogin(userObj.EmailId, userObj.Password, userObj.ConfirmPassword);
                if (returnValue)
                {
                    TempData["EmailId"] = userObj.EmailId;
                    return RedirectToAction("NewDeveloperProfile", "Developer");
                }
                else
                    return RedirectToAction("ErrorPage", "Alert");
            }
            return View("DSignUp");
        }

                //---------------------------------Developer Profile--------------------------------------------------
        public IActionResult Profile()
        {
            var em = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            var Obj = _mapper.Map<Models.Employee>(repObj.GetEmployeeByEmail(em));
            return View(Obj);
        }
         public IActionResult NewDeveloperProfile()
        {
            var d = (string)TempData["EmailId"];
            ViewBag.EmailId = d;
            TempData.Keep("EmailId");
            string developerid = repObj.GenerateNewEmployeeId();
            ViewBag.NextDeveloperId = developerid;
            return View();
        }

                //-------------------------------To save new developer ---------------------------------------------------
        public IActionResult SaveNewDeveloperProfile(Models.Employee userObj)
        {
            var d = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            userObj.EmailId = d;
            var returnValue = repObj.AddEmployee(userObj.EmployeeName, userObj.Gender, userObj.EmailId, userObj.ContactNumber, userObj.DateOfBirth, userObj.Designation, userObj.Domain, userObj.Location);
            if (returnValue)
                return RedirectToAction("AddCredentials", "Developer");
            else
                return RedirectToAction("ErrorPage", "Alert");
        }

                //-----------------------------Developer credentials----------------------------------------------------
        public IActionResult AddCredentials(IFormCollection frm)
        {
            var d = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            ViewBag.EmailAddress = d;
            return View();
        }
                //-----------------------------To save the developer credentials-----------------------------------------
        public IActionResult SaveNewDeveloperCredentials(Models.Credentials userObj)
        {
            if (ModelState.IsValid)
            {
                var d = (string)TempData["EmailId"];
                TempData.Keep("EmailId");
                userObj.EmailId = d;
                var returnValue = repObj.AddCredentials(userObj.EmailId, userObj.Experience, userObj.Domain, userObj.Certification, userObj.Rating);
                if (returnValue)
                {
                    
                    return RedirectToAction("DLogin", "Developer");
                }
                else
                    return View("Error");
            }
            return View("AddCredentials");
        }

                //-------------------------------To view credentials------------------------------------
        public IActionResult ViewCredentials()
        {
            var em = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            var obj = _mapper.Map<Models.Credentials>(repObj.GetCredentialsByEmail(em));
            return View(obj);
        }

                //-----------------------------------To Edit credentials--------------------------------------------------
        public IActionResult EditCredentials(Models.Credentials obj)
        {
            return View(obj);
        }

                //-----------------------------------To save the edited credentials---------------------------------------------------
        public IActionResult SaveEditedCredentials(Models.Credentials userObj)
        {
            var d = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            userObj.EmailId = d;
            var returnValue = repObj.UpdateCredentials(userObj.EmailId, userObj.Experience, userObj.Domain, userObj.Certification, userObj.Rating);
            if (returnValue)
            {
                return RedirectToAction("ViewCredentials", "Developer");
            }
            else
                return RedirectToAction("ErrorPage", "Alert");
        }

        //----------------------------------To calculate Credit points-------------------------------------------
        public ActionResult CalculateCredits(Models.Credentials obj, Models.CreditPoints ob)
        {

            int cp = repObj.CalculateCreditPoints(obj.Experience, obj.Certification, obj.Rating);
            var res = repObj.updateCreditPoints(obj.EmailId, obj.Domain, cp);
            var e = obj.EmailId;
            ViewBag.email = e;
            ViewBag.cp = cp;
            var Obj = _mapper.Map<Models.CreditPoints>(repObj.GetCredits(e));
            return View(Obj);

        }
        public ActionResult AddCreditPoints(Models.Credentials obj, Models.CreditPoints ob)
        {

            int cp = repObj.CalculateCreditPoints(obj.Experience, obj.Certification, obj.Rating);
            var res = repObj.InsertCreditPoints(obj.EmailId, obj.Domain, cp);
            var e = obj.EmailId;
            ViewBag.email = e;
            ViewBag.cp = cp;
            var Obj = _mapper.Map<Models.CreditPoints>(repObj.GetCredits(e));
            return View(Obj);

        }

                //--------------------------------------To edit developer profile----------------------------------
        public IActionResult EditProfile(Models.Employee obj)
        {
            return View(obj);
        }

                //-----------------------------To save the edited profile---------------------------------------------
        public IActionResult SaveEditedProfile(Models.Employee userObj)
        {
            var d = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            userObj.EmailId = d;
            userObj.EmployeeId = repObj.GetDeveloperIdByEmail(d);
            var returnValue = repObj.UpdateProfile(userObj.EmployeeId, userObj.ContactNumber, userObj.Designation, userObj.Domain, userObj.Location);
            if (returnValue)
            {

                return RedirectToAction("Profile", "Developer");
            }
            else
                return RedirectToAction("ErrorPage", "Alert");
        }

                //-------------------------------To display the projects of particular developer------------------------------
         public IActionResult notification()
         {
                var em = (string)TempData["EmailId"];
                TempData.Keep("EmailId");
            var lstdevos = repObj.GetDeveloperByEmail(em);
            List<Models.DeveloperProjectDetails> lstModeldevos = new List<Models.DeveloperProjectDetails>();
            foreach (var devop in lstdevos)
            {
                lstModeldevos.Add(_mapper.Map<Models.DeveloperProjectDetails>(devop));
              
            }
            return View(lstModeldevos);
            
        }
                //---------------------------To display the project status--------------------------------------------
        public IActionResult projectstatus(Models.DeveloperProjectDetails dpdobj)
        {
            var sdate = dpdobj.StartDate;
            var edate = dpdobj.EndDate;
            var mail = dpdobj.EmailId;
           string status= repObj.projectstatus(sdate, edate);
            //ViewBag.status = status;
            if (status=="In Progress")
            {
                return RedirectToAction("InProgress","Alert");
            }
            else
            {
                return RedirectToAction("Completed","Alert");
            }  
        }
        
                //--------------------------------To update developer status-------------------------------------------
        public IActionResult updateDeveloperStatus()
        {
            var email = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            var Object = repObj.fetchStatus(email);
            var sdate = Object.StartDate;
            var edate = Object.EndDate;
            var mail = (string)TempData["EmailId"];
            var developerStatus = repObj.updateAllocatedStatus(mail, sdate, edate);
            return RedirectToAction("notification", "Developer");
        }

                //---------------------------------To display the entire projects present------------------------------------
        public IActionResult projectdetails()
        {
            var lstdevos = repObj.GetClientProjectDetails();
            List<Models.ClientProjectDetails> lstModeldevos = new List<Models.ClientProjectDetails>();
            foreach (var devop in lstdevos)
            {
                lstModeldevos.Add(_mapper.Map<Models.ClientProjectDetails>(devop));                
            }
            return View(lstModeldevos);
        }


    }
}