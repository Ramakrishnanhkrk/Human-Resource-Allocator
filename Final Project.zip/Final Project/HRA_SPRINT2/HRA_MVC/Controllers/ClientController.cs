﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using HRA_DAL;
using HRA_DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HRA_MVC.Controllers
{
    public class ClientController : Controller
    {
        private readonly HRA_DBContext _context;
        HRA_Repository repObj;
        private readonly IMapper _mapper;
        public ClientController(HRA_DBContext context, IMapper mapper)
        {
            _context = context;
            repObj = new HRA_Repository(_context);
            _mapper = mapper;
        }
        
                 //-------------Client Login----------------------
        public IActionResult CLogin()
        {
            return View();
        }
                //------------------To verify the client------------------
        public IActionResult CheckedLoginDetails(IFormCollection frm)
        {

            string userId = frm["name"];
            string password = frm["pwd"];
            TempData["EmailId"] = userId;
            bool res = repObj.clientlogindetails(userId, password);
            if (res == true)
            {
                //return RedirectToAction("Success", "Alert");
                // HttpContext.Session.SetString("userId", userId);
                return RedirectToAction("ExistProject", "Client");
            }
            else
            {
                return RedirectToAction("ErrorPage", "Alert");
            }
        }

                //--------------------Client SignUp----------------------------
        public IActionResult CSignup()
        {
            string clientid = repObj.GenerateNewClientId();
            ViewBag.NextClientId = clientid;
            return View();
        }

                //-------------------To save the new Client----------------------
        public IActionResult SaveNewClient(Models.ClientLogin userObj)
        {
            if (ModelState.IsValid)
            {
                var returnValue = repObj.AddClientLogin(userObj.ClientName, userObj.EmailId, userObj.Password, userObj.ConfirmPassword);
                if (returnValue)
                    return RedirectToAction("CLogin", "Client");
                else
                    return RedirectToAction("ErrorPage", "Alert");
            }
            return View("CSignup");
        }

                //-----------------------To display existing projects of client-------------------
        public IActionResult ExistProject()
        {
            string em = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            var lstClients = repObj.GetClientByEmail(em);
            List<Models.ClientProjectDetails> lstModelClients = new List<Models.ClientProjectDetails>();
            foreach (var product in lstClients)
            {
                lstModelClients.Add(_mapper.Map<Models.ClientProjectDetails>(product));
            }
            return View(lstModelClients);
        }

                //--------------------------To make a new project request for developers--------------------
        public IActionResult NewRequest()
        {
            var a = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            ViewBag.mail = a;
            TempData["ClientId"] = repObj.GetClientIdByEmail(a);
            TempData.Keep("ClientId");
            string ProjectId = repObj.GenerateNewProjectId();
            TempData["NextProjectId"] = ProjectId;
            TempData.Keep("NextProjectId");
            return View();
        }
       
                //-------------------------------To save the project request and fetch eligible developers----------------------------
        public IActionResult SaveNewRequest_Listtopemp(Models.ClientProjectDetails userObj)
        {
            //if (ModelState.IsValid)
            //{
            var prjname = userObj.ProjectName;
            TempData["projname"] = prjname;
            var strdate = userObj.StartDate;
            TempData["strtdate"] = strdate;
            var enddate = userObj.EndDate;
            TempData["Enddate"] = enddate;
            var Domain = userObj.Stream;
            TempData["Domain"] = Domain;
            var no_emp = userObj.NoOfEmployeesReq;
            TempData["no_emp"] = no_emp;
            var a = (string)TempData["EmailId"];
            TempData.Keep("EmailId");
            var client_Id = repObj.GetClientIdByEmail(a);
            TempData["client_Id"] = client_Id;
            var top_emp = repObj.FetchTopEmployees(Domain, no_emp);
            var returnValue = repObj.AddClientProjectDetails(client_Id, a, userObj.ProjectName, userObj.Stream, userObj.StartDate, userObj.EndDate, userObj.NoOfEmployeesReq);
            if (top_emp != null)
            {
                List<Models.CreditPoints> lstModelClients = new List<Models.CreditPoints>();
                foreach (var empl in top_emp)
                {
                    lstModelClients.Add(_mapper.Map<Models.CreditPoints>(empl));
                }

                return View(lstModelClients);

            }
            else
                return View("ErrorPage");
            //}
            //return View("CSignup");
        }


                //-----------------------------To allocate projects to the developers-------------------------------------------
        public IActionResult allocation(Models.CreditPoints mail)
        {
            ClientProjectDetails cd = new ClientProjectDetails();
            var pid = (string)TempData["NextProjectId"];
            TempData.Keep("EmailId");
           var pname = (string)TempData["projname"];
            var domain = (string)TempData["Domain"];
            var no_emp = (int)TempData["no_emp"];
            TempData.Keep("no_emp");
            var sdate = (DateTime)TempData["strtdate"];
            TempData.Keep("EmailId");
            var edate = (DateTime)TempData["Enddate"];
            TempData.Keep("EmailId");
            var cid = (string)TempData["ClientId"];
            TempData.Keep("EmailId");
            var email = mail.EmailId;
            TempData["EmailId"] = email;

            cd.ProjectId = pid;
            cd.ClientId = cid;
            cd.EmailId = email;
            cd.ProjectName = pname;
            cd.Stream = domain;
            cd.StartDate = sdate;
            cd.EndDate = edate;
            cd.NoOfEmployeesReq = no_emp;

            var res = repObj.InsertDeveloperProjectDetails(email, pid, sdate, edate, cid);           
            repObj.updateAllocatedStatus(email, sdate,edate);
            var a = (int)TempData["no_emp"];
            a = a - 1;
            TempData["no_emp"] = a;
            cd.NoOfEmployeesReq = a;
            return RedirectToAction("SaveNewRequest_Listtopemp",cd);
            //return RedirectToAction("Success", "Alert");
   
        }

                //----------------------To view project status-----------------------------------------
        public IActionResult projectstatus(Models.DeveloperProjectDetails dpdobj)
        {
            var sdate = dpdobj.StartDate;
            var edate = dpdobj.EndDate;
            var mail = dpdobj.EmailId;
            string status = repObj.projectstatus(sdate, edate);
            //ViewBag.status = status;
            if (status == "In Progress")
            {
                return RedirectToAction("InProgress", "Alert");
            }
            else
            {
                return RedirectToAction("Completed", "Alert");
            }
        }
    }
}