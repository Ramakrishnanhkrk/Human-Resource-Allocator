﻿using HRA_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HRA_DAL
{
    public class HRA_Repository
    {
        public HRA_DBContext context;
        private readonly HRA_DBContext _context;

        public HRA_Repository()
        {
            context = new HRA_DBContext();
        }


        public HRA_Repository(HRA_DBContext context)
        {
            _context = context;

        }
        ///////-----------get commands---------------//////////
        public List<Employee> GetAllEmployee()
        {
            var employeeList = _context.Employee.ToList();
            return employeeList;
        }


        public List<EmployeeLogin> GetAllEmployeeLogin()
        {
            var employeeLoginList = _context.EmployeeLogin.ToList();
            return employeeLoginList;
        }


        public List<ClientLogin> GetAllClientLogin()
        {
            var clientLoginList = _context.ClientLogin.ToList();
            return clientLoginList;
        }


        public List<ClientProjectDetails> GetClientProjectDetails()
        {
            var cliProjList = _context.ClientProjectDetails.ToList();
            return cliProjList;
        }


        public List<DeveloperProjectDetails> GetProjectDetails()
        {
            var projList = _context.DeveloperProjectDetails.ToList();
            return projList;
        }
       

        //////----------------------------------------------------get by email----------------------------------------------------///////
        public Employee GetEmployeeByEmail(string email)
        {
            var employee = (from e in _context.Employee
                            where e.EmailId == email
                            select e).FirstOrDefault();
            return employee;
        }

        public Credentials GetCredentialsByEmail(string email)
        {
            var cred = (from e in _context.Credentials
                        where e.EmailId == email
                        select e).FirstOrDefault();
            return cred;
        }

        public CreditPoints GetCredits(string email)
        {
            var cred = (from e in _context.CreditPoints
                        where e.EmailId == email
                        select e).FirstOrDefault();
            return cred;
        }


        public string GetProjectname(string pid)
        {
            var cred = (from e in _context.ClientProjectDetails
                        where e.ProjectId == pid
                        select e.ProjectName).FirstOrDefault();
            return cred;
        }

        public List<Models.ClientProjectDetails> GetClientByEmail(string email)
        {
            try
            {
                var client = (from c in _context.ClientProjectDetails
                              where c.EmailId == email
                              select c).ToList();
                return client;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public List<Models.DeveloperProjectDetails> GetDeveloperByEmail(string email)
        {
            try
            {
                var dev = (from c in _context.DeveloperProjectDetails
                              where c.EmailId == email
                              select c).ToList();
                return dev;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<Models.ClientProjectDetails> GetClientProjectByEmail(string email)
        {
            try
            {
                var client = (from c in _context.ClientProjectDetails
                              where c.EmailId == email
                              select c).ToList();
                return client;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string GetClientIdByEmail(string mail)
        {
            try
            {
                var client = (from c in _context.ClientLogin
                              where c.EmailId == mail
                              select c.ClientId).FirstOrDefault();
                return client;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string GetDeveloperIdByEmail(string mail)
        {
            try
            {
                var developer = (from c in _context.Employee
                                 where c.EmailId == mail
                                 select c.EmployeeId).FirstOrDefault();
                return developer;
            }
            catch (Exception)
            {
                return null;
            }
        }

        //////-------------------------------------------------generate next id---------------------------------------------------------//////
        public string GenerateNewEmployeeId()
        {
            string employeeId;
            try
            {
                employeeId = (from p in _context.Employee
                              select
   HRA_DBContext.ufn_GenerateNewEmployeeId()).FirstOrDefault();
            }
            catch (Exception)
            {
                employeeId = null;
            }
            return employeeId;
        }


        public string GenerateNewClientId()
        {
            string clientId;
            try
            {
                clientId = (from p in _context.ClientLogin
                            select
   HRA_DBContext.ufn_GenerateNewClientId()).FirstOrDefault();
            }
            catch (Exception)
            {
                clientId = null;
            }
            return clientId;
        }



        public string GenerateNewProjectId()
        {
            string projectId;
            try
            {
                projectId = (from p in _context.ClientProjectDetails
                             select
  HRA_DBContext.ufn_GenerateNewProjectId()).FirstOrDefault();
            }
            catch (Exception)
            {
                projectId = null;
            }
            return projectId;
        }


        ///////----------------------------------------------------add methods--------------------------------------------------------------//////
        public bool AddEmployeeLogin(string emailId, string password, string confirmPassword)
        {
            bool status = false;
            EmployeeLogin emplog = new EmployeeLogin();
            emplog.EmailId = emailId;
            emplog.Password = password;
            emplog.ConfirmPassword = confirmPassword;
            try
            {
                //context.Categories.Add(category);
                _context.Add<EmployeeLogin>(emplog);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }



        public bool AddEmployee(string employeeName, string gender, string mailId, long contactNumber, DateTime dateOfBirth, string designation, string domain, string location)
        {
            bool status = false;
            Employee emp = new Employee();
            emp.EmployeeId = GenerateNewEmployeeId();
            emp.EmployeeName = employeeName;
            emp.Gender = gender;
            emp.EmailId = mailId;
            emp.ContactNumber = contactNumber;
            emp.DateOfBirth = dateOfBirth;
            emp.Designation = designation;
            emp.Domain = domain;
            emp.Location = location;
            emp.Allocation = "Not Allocated";

            try
            {
                //context.Categories.Add(category);
                _context.Add<Employee>(emp);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }




        public bool AddClientLogin(string clientName, string emailId, string password, string confirmPassword)
        {
            bool status = false;
            ClientLogin cl = new ClientLogin();
            cl.ClientId = GenerateNewClientId();
            cl.ClientName = clientName;
            cl.EmailId = emailId;
            cl.Password = password;
            cl.ConfirmPassword = confirmPassword;
            try
            {
                //context.Categories.Add(category);
                _context.Add<ClientLogin>(cl);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }



        public bool AddClientProjectDetails(string clientId, string emailId, string projectName, string stream, DateTime startDate, DateTime endDate, int noOfEmployeesReq)
        {
            bool status = false;
            ClientProjectDetails cpd = new ClientProjectDetails();
            cpd.ProjectId = GenerateNewProjectId();
            cpd.ClientId = clientId;
            cpd.EmailId = emailId;
            cpd.ProjectName = projectName;
            cpd.Stream = stream;
            cpd.StartDate = startDate;
            cpd.EndDate = endDate;
            cpd.NoOfEmployeesReq = noOfEmployeesReq;
            try
            {
                //context.Categories.Add(category);
                _context.Add<ClientProjectDetails>(cpd);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }



        public bool AddDeveloperProjectDetails(DeveloperProjectDetails Projlog)
        {
            bool status = false;
            try
            {
                //context.Categories.Add(category);
                _context.Add<DeveloperProjectDetails>(Projlog);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        public bool AddCredentials(string emailId, string experience, string domain, string certification, int rating)
        {
            bool status = false;
            Credentials cr = new Credentials();
            cr.EmailId = emailId;
            cr.Experience = experience;
            cr.Domain = domain;
            cr.Certification = certification;
            cr.Rating = rating;
            try
            {
                //context.Categories.Add(category);
                _context.Add<Credentials>(cr);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        ////-----------------------------------------login verification methods password & confirm password-----------------------------------------/////
        public bool emplogindetails(string username, string password)
        {


            try
            {
                var det = _context.EmployeeLogin.FirstOrDefault(p => p.EmailId == username && p.Password == password);
                if (det != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch
            {
                return false;
            }
        }



        public bool clientlogindetails(string username, string password)
        {
            try
            {
                var det = _context.ClientLogin.FirstOrDefault(p => p.EmailId == username && p.Password == password);
                if (det != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch
            {
                return false;
            }
        }

        ///////------------------------------------------------fetch top employees----------------------------------------------------///////
        public List<CreditPoints> FetchTopEmployees(string Domain, int no_emp)
        {
            List<CreditPoints> employeeList = new List<CreditPoints>();
            try
            {
                List<CreditPoints> list = (from c in _context.ClientProjectDetails
                                           join e in _context.Employee on
                                           c.Stream equals e.Domain
                                           join cr in _context.CreditPoints on
                                           e.EmailId equals cr.EmailId
                                           where e.Allocation!= "Allocated" && cr.Domain == Domain
                                           orderby cr.Credits descending
                                           // OrderByDescending(cr=>cr.Credits)                           
                                           select cr).Distinct().ToList<CreditPoints>();
                if (list.Count > no_emp)
                {
                    for (int i = 0; i < no_emp; i++)
                    {
                        employeeList.Add(list[i]);
                    }
                }
                else
                {
                    employeeList = list;
                }

            }
            catch
            {

                employeeList = null;
            }
            return employeeList;
        }

        //////----------------------------------------------------update methods----------------------------------------------------------/////////
        public bool UpdateCredentials(string mail, string exp, string domain, string certificate, int rating)
        {
            bool status = false;
            Credentials credit = _context.Credentials.Find(mail);
            try
            {
                if (credit != null)
                {
                    credit.Experience = exp;
                    credit.Domain = domain;
                    credit.Certification = certificate;
                    credit.Rating = rating;
                    _context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool UpdateProfile(string EmployeeId, long cn, string des, string domain, string location)
        {
            bool status = false;
            Employee credit = _context.Employee.Find(EmployeeId);
            try
            {
                if (credit != null)
                {
                    credit.ContactNumber = cn;
                    credit.Designation = des;
                    credit.Domain = domain;
                    credit.Location = location;
                    _context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }


        public bool updateCreditPoints(string emailId, string domain, int credits)
        {
            bool status = false;
            CreditPoints credit = _context.CreditPoints.Find(emailId);
            try
            {
                if (credit != null)
                {
                    credit.Domain = domain;
                    credit.Credits = credits;
                    _context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }


        /////---------------------------------------------inserting into tables----------------------------------------------////////
        public bool InsertCreditPoints(string emailId, string domain, int credits)
        {
            bool status = false;
            CreditPoints credObj = new CreditPoints();
            credObj.EmailId = emailId;
            credObj.Domain = domain;
            credObj.Credits = credits;
            try
            {
                //context.Categories.Add(category);
                _context.Add<CreditPoints>(credObj);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }


        public bool InsertDeveloperProjectDetails(string email, string pid,DateTime sdate,DateTime edate,string cid)
        {
            bool status = false;
            DeveloperProjectDetails dObj = new DeveloperProjectDetails();
            dObj.EmailId = email;
            dObj.ProjectId = pid;
            dObj.StartDate= sdate;
            dObj.EndDate = edate;
            dObj.ClientId = cid;
            try
            {
                //context.Categories.Add(category);
                _context.Add<DeveloperProjectDetails>(dObj);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }



        ///////------------------------------------------------Credit points calculation--------------------------------------------------//////
        public int CalculateCreditPoints(string experience, string certification, int rating)
        {
            int c;
            Credentials cp = new Credentials();
            cp.Experience = experience;
            cp.Certification = certification;
            cp.Rating = rating;
            if ((cp.Experience.ToLower()) == "beginner")
            {
                c = 1;
                if (cp.Certification.ToLower() == "yes")
                {
                    c += 1;
                }
                c += cp.Rating;
            }
            else if ((cp.Experience.ToLower()) == "intermediate")
            {
                c = 2;
                if (cp.Certification.ToLower() == "yes")
                {
                    c += 1;
                }
                c += cp.Rating;
            }
            else
            {
                c = 3;
                if (cp.Certification.ToLower() == "yes")
                {
                    c += 1;
                }
                c += cp.Rating;
            }
            return c;
        }

        //////-------------ALLOCATED UPDATION------///////
        public string all(DateTime sdate,DateTime edate)
        {
            string all;
            double d = (edate - sdate).TotalDays;
            double t = (DateTime.Now.Date-sdate).TotalDays;
            if(t>=d)
            {
                all = "Not Allocated";
            }
            else
            {
                all = "Allocated";
            }
            return all;
        }
        public bool updateAllocatedStatus(string mail,DateTime sdate,DateTime edate)
        {
            bool status = false;
            string eid = GetDeveloperIdByEmail(mail);
            Employee em = _context.Employee.Find(eid);
            try
            {
                if (em != null)
                {
                    em.Allocation = all(sdate, edate);
                    _context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }


        /////----------------------------------------project status------------------------------------------------//////
        public string projectstatus(DateTime sdate, DateTime edate)
        {
            string ps;
            double d = (edate - sdate).TotalDays;
            double t = (DateTime.Now.Date - sdate).TotalDays;
            if (t >= d)
            {
                ps = "Completed";
            }
            else
            {
                ps = "In Progress";
            }
            return ps;
        }

        /////-----update allocation status-----////
        public DeveloperProjectDetails fetchStatus(string email)
        {

            var empObj = (from p in _context.DeveloperProjectDetails
                          where p.EmailId == email
                          select p).LastOrDefault();


            return empObj;

        }


    }
}
