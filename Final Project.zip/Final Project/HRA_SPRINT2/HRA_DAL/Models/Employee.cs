﻿using System;
using System.Collections.Generic;

namespace HRA_DAL.Models
{
    public partial class Employee
    {
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Gender { get; set; }
        public string EmailId { get; set; }
        public long ContactNumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Designation { get; set; }
        public string Domain { get; set; }
        public string Location { get; set; }
        public string Allocation { get; set; }

        public EmployeeLogin Email { get; set; }
    }
}
