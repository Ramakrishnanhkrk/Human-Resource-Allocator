﻿using System;
using System.Collections.Generic;

namespace HRA_DAL.Models
{
    public partial class ClientProjectDetails
    {
        public string ProjectId { get; set; }
        public string ClientId { get; set; }
        public string EmailId { get; set; }
        public string ProjectName { get; set; }
        public string Stream { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int NoOfEmployeesReq { get; set; }

        public ClientLogin Client { get; set; }
        public ClientLogin Email { get; set; }
    }
}
