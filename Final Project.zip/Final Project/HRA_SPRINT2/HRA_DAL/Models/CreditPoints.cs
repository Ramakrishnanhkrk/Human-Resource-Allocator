﻿using System;
using System.Collections.Generic;

namespace HRA_DAL.Models
{
    public partial class CreditPoints
    {
        public string EmailId { get; set; }
        public string Domain { get; set; }
        public int Credits { get; set; }
    }
}
